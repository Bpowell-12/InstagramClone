package com.example.instagramclone;

import android.app.Application;

import com.parse.Parse;
import com.parse.ParseObject;

public class ParseApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        // Register your parse models
        ParseObject.registerSubclass(Post.class);

        Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("7qc388iKVI45zf7dHgZbXLmjFS1EU1JydAYXn4jL")
                .clientKey("g95j7XZl4kzNaD9GHI1b6xLp0TCFydgij78EI4be")
                .server("https://parseapi.back4app.com")
                .build()
        );
    }
}
